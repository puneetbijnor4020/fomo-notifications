<?php
/*
Plugin Name: Fake FOMO Notifications Plugin
Plugin URI: https://github.com/puneetbijnor4020/fomo-notifications/
Description: A plugin to display FOMO notifications with Font Awesome icon selection.
Version: 1.0
Author: VariSoft
Author URI: https://github.com/puneetbijnor4020/
License: GPL2
*/

if (!defined('ABSPATH')) exit; // Exit if accessed directly

// Create notifications table on plugin activation
function fomo_create_notifications_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'fomo_notifications';

    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            persons text NOT NULL,
            messages text NOT NULL,
            icon varchar(255) NOT NULL,
            display_time int NOT NULL,
            sound_alert tinyint(1) NOT NULL,
            shortcode varchar(255) NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
register_activation_hook(__FILE__, 'fomo_create_notifications_table');

function fomo_plugin_uninstall() {
    global $wpdb;

    // Delete custom table
    $table_name = $wpdb->prefix . 'fomo_notifications';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");

    // Optionally delete plugin options
    delete_option('fomo_notification_messages');
    delete_option('fomo_icon');
    delete_option('fomo_display_time');
}

register_uninstall_hook(__FILE__, 'fomo_plugin_uninstall');

// Register settings pages
function fomo_create_menu() {
    add_menu_page('FOMO Notifications', 'FOMO Notifications', 'manage_options', 'fomo-notifications', 'fomo_list_notifications');
    add_submenu_page('fomo-notifications', 'Add Notification', 'Add New', 'manage_options', 'fomo-notification-add', 'fomo_add_edit_notification');
}
add_action('admin_menu', 'fomo_create_menu');


function fomo_list_notifications() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'fomo_notifications';
    $notifications = $wpdb->get_results("SELECT * FROM $table_name");

    if (isset($_GET['delete'])) {
        $notification_id = intval($_GET['delete']);
        $wpdb->delete($table_name, ['id' => $notification_id]);
        wp_redirect(admin_url('admin.php?page=fomo-notifications'));
        exit;
    }

    echo '<div class="wrap"><h1>All Notifications</h1>';
    echo '<a href="?page=fomo-notification-add" class="button-primary">Add New Notification</a>';
    echo '<table class="widefat fixed" cellspacing="0">
            <thead><tr><th>Name</th><th>Shortcode</th><th>Actions</th></tr></thead>
            <tbody>';

    foreach ($notifications as $notification) {
        echo '<tr>';
        echo '<td>' . esc_html($notification->name) . '</td>';
        echo '<td>[fomo_notification id="' . esc_attr($notification->id) . '"]</td>';
        echo '<td><a href="?page=fomo-notification-add&id=' . esc_attr($notification->id) . '" class="button">Edit</a> ';
        echo '<a href="?page=fomo-notifications&delete=' . esc_attr($notification->id) . '" class="button">Delete</a></td>';
        echo '</tr>';
    }

    echo '</tbody></table></div>';
}


function fomo_add_edit_notification() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'fomo_notifications';
    $is_edit = isset($_GET['id']);
    $notification = $is_edit ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $_GET['id'])) : null;

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = sanitize_text_field($_POST['name']);
        $messages = sanitize_textarea_field($_POST['messages']);
        $persons = sanitize_textarea_field($_POST['persons']);
        $icon = sanitize_text_field($_POST['icon']);
        $display_time = intval($_POST['display_time']);
        $sound_alert = isset($_POST['sound_alert']) ? 1 : 0;

        if ($is_edit) {
            $wpdb->update(
                $table_name,
                compact('name','persons', 'messages', 'icon', 'display_time', 'sound_alert'),
                ['id' => $_GET['id']]
            );
        } else {
            $shortcode = uniqid('fomo_');
            $wpdb->insert(
                $table_name,
                compact('name', 'persons','messages', 'icon', 'display_time', 'sound_alert', 'shortcode')
            );
        }

        wp_redirect(admin_url('admin.php?page=fomo-notifications'));
        exit;
    }

    // Render form for adding/editing
    ?>
    <div class="wrap">
        <h1><?php echo $is_edit ? 'Edit' : 'Add'; ?> Notification</h1>
        <form method="post">
            <!-- <table class="form-table">
                <tr><th>Name</th><td><input type="text" name="name" value="<?php echo esc_attr($notification->name ?? ''); ?>" required></td></tr>
                <tr><th>Messages (comma-separated)</th><td><textarea name="messages"><?php echo esc_textarea($notification->messages ?? ''); ?></textarea></td></tr>
                <tr><th>Icon</th><td><input type="text" name="icon" value="<?php echo esc_attr($notification->icon ?? ''); ?>"></td></tr>
                <tr><th>Display Time (ms)</th><td><input type="number" name="display_time" value="<?php echo esc_attr($notification->display_time ?? 5000); ?>" required></td></tr>
                <tr><th>Sound Alert</th><td><input type="checkbox" name="sound_alert" <?php checked($notification->sound_alert ?? 0, 1); ?>> Enable Sound</td></tr>
            </table>
            <?php submit_button(); ?> 
            -->

            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Name</th>
                    <td><input type="text" name="name" value="<?php echo esc_attr($notification->name ?? ''); ?>" required></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Persons (separate by commas)</th>
                    <td><textarea name="persons" rows="5"><?php echo esc_textarea($notification->persons ?? ''); ?></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Action Messages (separate by commas)</th>
                    <td><textarea name="messages" rows="5"><?php echo esc_textarea($notification->messages ?? ''); ?></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Icon</th>
                    <td>
                        <button type="button" id="icon-selector-btn" class="button">Select Icon</button>
                        <input type="hidden" id="fomo_icon" name="icon" value="<?php echo esc_attr($notification->icon ?? ''); ?>" />
                        <div id="selected-icon-preview"><i class="fomo-icon fas <?php echo esc_attr($notification->icon ?? ''); ?>"></i></div>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Display Time (ms)</th>
                    <td><input type="number" name="display_time" value="<?php echo esc_attr($notification->display_time ?? 5000); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Notification Sound Alert</th>
                    <td>
                        <input type="checkbox" name="sound_alert" value="1" <?php checked($notification->sound_alert ?? 0, 1); ?> /> Enable Sound Alert
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>

    <!-- Modal for Icon Selection -->
    <div id="icon-selector-modal" class="icon-modal">
        <div class="icon-modal-content">
            <span class="icon-modal-close">&times;</span>
            <h2>Select an Icon</h2>
            <div id="fomo-icon-grid">
                <!-- Icons will be loaded here -->
            </div>
        </div>
    </div>
    <?php
}



// Function to get Font Awesome icons dynamically from CSS file
function get_font_awesome_icons() {
    $icons = [];
    $css_file = plugin_dir_path(__FILE__) . 'assets/fontawesome.min.css';

    if (file_exists($css_file)) {
        $css_content = file_get_contents($css_file);
        preg_match_all('/\.fa-([a-z0-9-]+):before/', $css_content, $matches);

        if (!empty($matches[1])) {
            foreach ($matches[1] as $icon) {
                $icons[] = "fa-$icon";
            }
        }
    }
    return $icons;
}

// Enqueue admin scripts and styles
function fomo_enqueue_admin_scripts($hook) {
    // Update this check to match the new top-level menu slug
    // echo '<script>console.log("'.$hook.'");</script>';
    if ($hook !== 'fomo-notifications_page_fomo-notification-add') return;

    wp_enqueue_style('font-awesome', plugins_url('/assets/fontawesome.min.css', __FILE__));
    wp_enqueue_style('fomo-admin-style', plugins_url('/css/fomo-admin.css', __FILE__));
    wp_enqueue_script('fomo-admin-script', plugins_url('/js/fomo-admin.js', __FILE__), array('jquery'), null, true);

    // Load Font Awesome icons dynamically
    $icons = get_font_awesome_icons();
    wp_localize_script('fomo-admin-script', 'fomoIcons', $icons);
}
add_action('admin_enqueue_scripts', 'fomo_enqueue_admin_scripts');

// Enqueue front-end scripts and styles
function fomo_enqueue_frontend_scripts() {
    wp_enqueue_style('fomo-style', plugins_url('/css/fomo-style.css', __FILE__));
    wp_enqueue_script('fomo-script', plugins_url('/js/fomo-script.js', __FILE__), array(), null, true);
}
add_action('wp_enqueue_scripts', 'fomo_enqueue_frontend_scripts');


// Shortcode for displaying notifications
function fomo_display_notification($atts) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'fomo_notifications';

    $atts = shortcode_atts(['id' => 0], $atts, 'fomo_notification');
    $notification = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $atts['id']));

    // Pass notification settings to JavaScript
    $data = array(
        'icon' => esc_attr($notification->icon),
        'messages' => explode(',', esc_attr($notification->messages)),
        'persons'=>explode(',', esc_attr($notification->persons)),
        'displayTime' => intval($notification->display_time),
        'soundAlert' => ($notification->sound_alert) // Pass the sound alert setting
    );
    wp_localize_script('fomo-script', 'fomoSettings', $data);

    if (!$notification) return '';

    $output = '<div id="fomo-container" class="fomo-container">
                    <!-- Notifications will be appended here dynamically -->
                </div>';

    return $output;
}
add_shortcode('fomo_notification', 'fomo_display_notification');


?>
