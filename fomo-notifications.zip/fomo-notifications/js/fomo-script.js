document.addEventListener('DOMContentLoaded', function() {
    if (typeof fomoSettings !== 'undefined' && fomoSettings.icon !='') {
        const container = document.getElementById('fomo-container');
        const actions = fomoSettings.messages;    
        const persons = fomoSettings.persons;
        let messages =[];
        //https://passiveincomeonline.in/wp-content/uploads/2024/10/250-milliseconds-of-silence.mp3
        // document.body.innerHTML += '<iframe src="https://passiveincomeonline.in/wp-content/uploads/2024/10/250-milliseconds-of-silence.mp3" allow="autoplay" id="audio"></iframe>';
        
        let beat = new Audio('https://passiveincomeonline.in/wp-content/plugins/fomo-notifications/level-up-191997.mp3');
        
        //https://passiveincomeonline.in/wp-content/uploads/2024/10/vibrating-message-37619.mp3
        //https://passiveincomeonline.in/wp-content/uploads/2024/10/message-alert-190042.mp3
        //https://passiveincomeonline.in/wp-content/uploads/2024/10/ding-sound-246413.mp3
        //https://passiveincomeonline.in/wp-content/uploads/2024/10/level-up-191997.mp3
        
        messages = persons.map((p,i)=>{
            let actionIndex = (i + 1) % actions.length;
            const ago = Math.floor(Math.random() * 59) + 1;
            return `<strong>${p}</strong> has ${actions[actionIndex]} <strong>${ago} minutes ago</strong>!`;
        });

        let index = 0;

        function showNotification(message) {
            // Create a new notification element
            const notificationElement = document.createElement('div');
            notificationElement.className = 'fomo-notification show';
            notificationElement.innerHTML = `<div style="width:20%;">
                                                <i style="font-size:2rem;" class="fas ${fomoSettings.icon}"></i>
                                            </div>
                                            <div style="width:80%;">
                                                <div style="font-size:1.1rem;"><u><strong>Hurry up!</strong></u></div>
                                                <div>${message}</div>
                                            </div>`;

            // Append the notification to the container
            container.appendChild(notificationElement);
            
            if(fomoSettings.soundAlert){
                beat.play();    
            }
                

            // Hide the notification after a specific duration
            setTimeout(() => {
                notificationElement.classList.remove('show'); // Start hiding
                setTimeout(() => {
                    notificationElement.remove(); // Remove from DOM after transition
                }, 500); // Wait for transition to finish before removing
            }, fomoSettings.displayTime/2);
        }

        function displayNotifications() {        
            if (messages.length === 0) return;

            // Show the next notification
            showNotification(messages[index]);
            index = (index + 1) % messages.length; // Loop through messages

            // Set a timeout to display the next notification
            setTimeout(displayNotifications, fomoSettings.displayTime ); // Adjust timing for the next notification
        }

        // Start displaying notifications if messages are present
        if (messages.length > 0) {
            displayNotifications();
        }
    }
});
