jQuery(document).ready(function($) {
    const modal = $('#icon-selector-modal');
    const iconGrid = document.getElementById('fomo-icon-grid');
    const selectedIconInput = document.getElementById('fomo_icon');
    const selectedIconPreview =document.getElementById('selected-icon-preview');

    // Open modal
    $('#icon-selector-btn').click(function() {
        modal.show();
    });

    // Close modal
    $('.icon-modal-close').click(function() {
        modal.hide();
    });

    // Close modal when clicking outside of it
    $(window).click(function(event) {
        if ($(event.target).is(modal)) {
            modal.hide();
        }
    });

    // Populate icon grid with Font Awesome icons
    fomoIcons.forEach(icon => {
        const iconElement = document.createElement('i');
        iconElement.className = `fomo-icon fas ${icon}`;
        iconElement.dataset.icon = icon;

        iconElement.addEventListener('click', function () {
            const selectedIconClass = this.dataset.icon;
            selectedIconInput.value =selectedIconClass;
            document.querySelectorAll('.fomo-icon').forEach(el => el.style.color = '#333'); // Reset color
            this.style.color = '#0073aa'; // Highlight selected

            selectedIconPreview.innerHTML=`<i class="fomo-icon fas ${selectedIconClass}"></i>`;
            modal.hide();
        });
        iconGrid.appendChild(iconElement);
    });

    
});
